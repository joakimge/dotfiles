((buffer-size . 2548) (buffer-checksum . "e893eab6b9c2c62f23ce7a54c40f2b9bf5897331"))
((emacs-buffer-undo-list nil (1920 . 1921) 1919 nil (nil rear-nonsticky nil 2497 . 2498) (nil fontified nil 1921 . 2498) (1921 . 2498) nil (1920 . 1921) (t 27209 8244 426659 267000) 1891 nil (";; --- Visual polish ---
(use-package org-modern
  :after org
  :hook (org-mode . org-modern-mode)
  :config
  (setq org-modern-star 'replace          ; heading stars → clean symbols
        org-modern-table t                ; styled table lines
        org-modern-keyword t))            ; #+keywords: styled subtly

;; Markers (*bold*, /italic/) reappear under the cursor for editing.
(use-package org-appear
  :after org
  :hook (org-mode . org-appear-mode)
  :config
  (setq org-appear-autoemphasis t
        org-appear-autolinks t))          ; links also expand under point" . 1892) ((marker . 1921) . -576) ((marker . 1922) . -576) ((marker . 2498) . -576) ((marker) . -504) ((marker . 1892) . -576) ((marker . 1892) . -576) (nil fontified t 2369 . 2396) (nil fontified t 2365 . 2369) (nil fontified t 2361 . 2365) (nil fontified t 2354 . 2361) (nil fontified t 2322 . 2354) (nil fontified t 2317 . 2322) (nil fontified t 2310 . 2317) (nil fontified t 2304 . 2310) (nil fontified t 2290 . 2304) (nil fontified t 2279 . 2290) (nil fontified t 2278 . 2279) (nil fontified t 2212 . 2278) (nil fontified t 2209 . 2212) (nil fontified t 2208 . 2209) (nil fontified t 2182 . 2208) (nil fontified t 2180 . 2182) (nil fontified t 2138 . 2180) (nil fontified t 2119 . 2138) (nil fontified t 2117 . 2119) (nil fontified t 2075 . 2117) (nil fontified t 2045 . 2075) (nil fontified t 2043 . 2045) (nil fontified t 2008 . 2043) (nil fontified t 2004 . 2008) (nil fontified t 2000 . 2004) (nil fontified t 1993 . 2000) (nil fontified t 1961 . 1993) (nil fontified t 1956 . 1961) (nil fontified t 1949 . 1956) (nil fontified t 1943 . 1949) (nil fontified t 1929 . 1943) (nil fontified t 1918 . 1929) (nil fontified t 1917 . 1918) (nil fontified t 1895 . 1917) (nil fontified t 1892 . 1895) (nil rear-nonsticky t 2468 . 2469) nil (nil rear-nonsticky nil 2468 . 2469) (nil fontified nil 1892 . 2469) (1892 . 2469) 1891 (t 27209 8244 426659 267000) nil (1969 . 1970) nil (nil rear-nonsticky nil 1968 . 1969) (nil fontified nil 1 . 1969) (1 . 1969) (t . -1)) (emacs-pending-undo-list (1969 . 1970) nil (nil rear-nonsticky nil 1968 . 1969) (nil fontified nil 1 . 1969) (1 . 1969) (t . -1)) (emacs-undo-equiv-table (4 . -1)))