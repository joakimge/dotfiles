((buffer-size . 1957) (buffer-checksum . "c9d694fcdccb26d9a15c6cd614e4ff2fdcd521e5"))
((emacs-buffer-undo-list nil (nil rear-nonsticky nil 508 . 509) (nil fontified nil 195 . 509) (195 . 509) ("(use-package no-littering
  :init
  (setq no-littering-etc-directory (expand-file-name \"etc/\" user-emacs-directory)
        no-littering-var-directory (expand-file-name \"var/\" user-emacs-directory)))" . 195) ((marker . 508) . -116) ((marker . 195) . -116) ((marker . 195) . -116) ((marker) . -199) ((marker . 508) . -198) (t 27208 51268 16024 660000)) (emacs-pending-undo-list) (emacs-undo-equiv-table))