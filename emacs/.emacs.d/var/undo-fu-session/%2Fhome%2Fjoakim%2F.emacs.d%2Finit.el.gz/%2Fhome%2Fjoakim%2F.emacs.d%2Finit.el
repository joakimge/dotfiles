((buffer-size . 3530) (buffer-checksum . "5f8754f8eb7362998fe57e49cab5be2ef6d9a4bc"))
((emacs-buffer-undo-list nil (691 . 692) 611 nil (492 . 493) 491 nil (nil rear-nonsticky nil 689 . 690) (nil fontified nil 493 . 690) (493 . 690) (t 27209 8265 305507 52000) nil (nil rear-nonsticky nil 3306 . 3307) (nil fontified nil 3297 . 3307) (3297 . 3307) 3296 nil (3289 . 3297) (3287 . 3287) (3287 . 3289) (3286 . 3287) (t 27209 5818 632325 616000) 3270 nil (3281 . 3285) (3280 . 3280) (3280 . 3281) ("ide" . 3280) ((marker . 3479) . -2) ((marker) . -3) ((marker) . -3) nil (nil rear-nonsticky nil 3269 . 3270) ("
" . -3284) (3269 . 3285) 3255 (t 27208 63520 687821 513000) nil (3266 . 3269) (3264 . 3264) (3264 . 3266) ("\\" . -3264) ((marker . 3467) . -1) ((marker . 3463) . -1) ((marker . 3463) . -1) ((marker . 3463) . -1) ((marker) . -1) 3265 (3264 . 3265) (3263 . 3264) (3260 . 3263) ("e" . -3260) ((marker . 3467) . -1) ((marker . 3467) . -1) ((marker . 3459) . -1) ((marker) . -1) 3261 (3260 . 3261) (3257 . 3260) (3255 . 3255) (3255 . 3257) (3254 . 3255) (t 27208 60455 802727 257000) 3228 nil ("

(setq evil-normal-state-cursor   'box)   ; Solid block cursor in Normal state
(setq evil-visual-state-cursor   'box)   ; Solid block cursor in Visual state
(setq evil-motion-state-cursor   'box)   ; Solid block cursor in Motion state
(setq evil-insert-state-cursor   'bar)   ; Thin vertical bar in Insert state
(setq evil-emacs-state-cursor    'hbar)  ; Horizontal underline bar in Emacs state
" . 3255) ((marker . 3507) . -1) ((marker . 3507) . -395) ((marker . 3507) . -1) ((marker . 3507) . -1) ((marker) . -1) ((marker . 3507) . -1) (3650 . 3651) (nil rear-nonsticky t 3255 . 3256) nil (nil rear-nonsticky nil 3255 . 3256) ("
" . -3650) (3255 . 3651) nil ("
(setq evil-normal-state-cursor   'box)   ; Solid block cursor in Normal state
(setq evil-visual-state-cursor   'box)   ; Solid block cursor in Visual state
(setq evil-motion-state-cursor   'box)   ; Solid block cursor in Motion state
(setq evil-insert-state-cursor   'bar)   ; Thin vertical bar in Insert state
(setq evil-emacs-state-cursor    'hbar)  ; Horizontal underline bar in Emacs state
" . 3255) ((marker* . 3507) . 395) ((marker . 3507) . -394) ((marker . 3507) . -312) ((marker . 3507) . -157) ((marker . 3507) . -157) ((marker . 3507) . -79) ((marker . 3507) . -312) ((marker . 3507) . -312) ((marker) . -312) ((marker) . -312) ((marker) . -395) ((marker) . -395) 3567 (t 27208 60356 968504 817000) nil ("j" . -3255) ((marker . 3507) . -1) ((marker . 3507) . -1) ("k" . -3256) ((marker . 3507) . -1) ((marker . 3507) . -1) ("j" . -3257) ((marker . 3507) . -1) ((marker . 3507) . -1) ("k" . -3258) ((marker . 3507) . -1) ("l" . -3259) ((marker . 3507) . -1) 3260 (3256 . 3260) (3255 . 3255) (3255 . 3256) (t 27208 60331 888702 275000) nil ("
" . 3255) nil (nil rear-nonsticky nil 3255 . 3256) ("
" . -3650) (3255 . 3651) nil (3254 . 3255) (t 27208 58790 289308 709000) 3228 nil ("s" . 3253) (t 27208 58750 628665 672000) nil (3241 . 3255) (3237 . 3241) ("\\" . -3237) 3238 (3237 . 3238) ("\\" . -3237) ("'" . -3238) 3239 (3237 . 3239) (";" . -3237) 3238 (3237 . 3238) ("\\" . -3237) 3238 (3237 . 3238) ("\\" . -3237) ("-" . -3238) 3239 (3233 . 3239) ("r" . -3233) 3234 (3228 . 3234) (3227 . 3228) 3203 nil (1970 . 1971) (t 27208 55576 825849 32000)) (emacs-pending-undo-list ("
(setq evil-normal-state-cursor   'box)   ; Solid block cursor in Normal state
(setq evil-visual-state-cursor   'box)   ; Solid block cursor in Visual state
(setq evil-motion-state-cursor   'box)   ; Solid block cursor in Motion state
(setq evil-insert-state-cursor   'bar)   ; Thin vertical bar in Insert state
(setq evil-emacs-state-cursor    'hbar)  ; Horizontal underline bar in Emacs state
" . 3255) ((marker* . 3507) . 395) ((marker . 3507) . -394) ((marker . 3507) . -312) ((marker . 3507) . -157) ((marker . 3507) . -157) ((marker . 3507) . -79) ((marker . 3507) . -312) ((marker . 3507) . -312) ((marker) . -312) ((marker) . -312) ((marker) . -395) ((marker) . -395) 3567 (t 27208 60356 968504 817000) nil ("j" . -3255) ((marker . 3507) . -1) ((marker . 3507) . -1) ("k" . -3256) ((marker . 3507) . -1) ((marker . 3507) . -1) ("j" . -3257) ((marker . 3507) . -1) ((marker . 3507) . -1) ("k" . -3258) ((marker . 3507) . -1) ("l" . -3259) ((marker . 3507) . -1) 3260 (3256 . 3260) (3255 . 3255) (3255 . 3256) (t 27208 60331 888702 275000) nil ("
" . 3255) nil (nil rear-nonsticky nil 3255 . 3256) ("
" . -3650) (3255 . 3651) nil (3254 . 3255) (t 27208 58790 289308 709000) 3228 nil ("s" . 3253) (t 27208 58750 628665 672000) nil (3241 . 3255) (3237 . 3241) ("\\" . -3237) 3238 (3237 . 3238) ("\\" . -3237) ("'" . -3238) 3239 (3237 . 3239) (";" . -3237) 3238 (3237 . 3238) ("\\" . -3237) 3238 (3237 . 3238) ("\\" . -3237) ("-" . -3238) 3239 (3233 . 3239) ("r" . -3233) 3234 (3228 . 3234) (3227 . 3228) 3203 nil (1970 . 1971) (t 27208 55576 825849 32000)) (emacs-undo-equiv-table (9 . -1)))